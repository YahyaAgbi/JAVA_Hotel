/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Projet;
import java.sql.*;
import javax.swing.JOptionPane;
/**
 *
 * @author asus
 */
public class Tables_Hotel {
    
    public static void main(String args[]){
    
    Connection con = null;
    Statement st = null;
    try{
    con=Hotellog.connect();
    st=con.createStatement();
    st.executeUpdate("create Table Users(id int  primary key Auto_Increment , Name Varchar(20),email Varchar(100),password Varchar(30))");
    JOptionPane.showMessageDialog(null,"Table Crée !");
    }catch(Exception e){
    JOptionPane.showMessageDialog(null, e);
    }
    finally{
      try{
          
    con.close();
    st.close();
    
    
      }catch(Exception e){
    
    }
    }
    
    
    }
}
